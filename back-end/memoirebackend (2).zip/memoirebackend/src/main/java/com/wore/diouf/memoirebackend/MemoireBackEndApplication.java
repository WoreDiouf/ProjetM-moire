package com.wore.diouf.memoirebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MemoireBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(MemoireBackEndApplication.class, args);
	}

}
