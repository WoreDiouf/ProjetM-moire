package com.wore.diouf.memoirebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MemoireBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
